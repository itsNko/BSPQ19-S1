package es.deusto.client.gui;

import static org.junit.Assert.*;

import org.junit.Test;

public class VentanaDescuentoTest {

	@Test
	public void calcularPrecioDescontadoTest() {
		
	}

}
